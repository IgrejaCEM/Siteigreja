require('dotenv').config();
const path = require('path');

const config = {
  jwtSecret: process.env.JWT_SECRET || 'igreja-eventos-jwt-secret-key-2024',
  database: {
    client: 'sqlite3',
    connection: {
      filename: path.join(__dirname, '../../database.sqlite')
    },
    useNullAsDefault: true,
    pool: {
      afterCreate: (conn, cb) => {
        conn.run('PRAGMA foreign_keys = ON', cb);
      }
    }
  },
  server: {
    port: process.env.PORT || 3001,
    cors: {
      origin: process.env.NODE_ENV === 'production' 
        ? 'https://seu-dominio.com' 
        : 'http://localhost:5173',
      credentials: true
    }
  }
};

module.exports = config; 