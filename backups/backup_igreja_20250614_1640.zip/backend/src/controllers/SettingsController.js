const { db } = require('../database/db');

class SettingsController {
  async getHomeLayout(req, res) {
    try {
      const settings = await db('settings').first();
      return res.json({ layout: settings?.homeLayout ? JSON.parse(settings.homeLayout) : [] });
    } catch (error) {
      console.error('Erro ao buscar layout:', error);
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }

  async updateHomeLayout(req, res) {
    try {
      const { layout } = req.body;
      
      // Verificar se já existe um layout
      const existingSettings = await db('settings').first();
      
      if (existingSettings) {
        // Atualizar layout existente
        await db('settings')
          .update({
            homeLayout: JSON.stringify(layout),
            updatedAt: new Date()
          });
      } else {
        // Criar novo layout
        await db('settings').insert({
          homeLayout: JSON.stringify(layout),
          createdAt: new Date(),
          updatedAt: new Date()
        });
      }
      
      return res.json({ message: 'Layout atualizado com sucesso' });
    } catch (error) {
      console.error('Erro ao atualizar layout:', error);
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }

  async getHomeContent(req, res) {
    try {
      const settings = await db('settings').first();
      return res.json({
        content: settings?.homeContent || '',
        css: settings?.homeCss || ''
      });
    } catch (error) {
      console.error('Erro ao buscar conteúdo:', error);
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }

  async updateHomeContent(req, res) {
    try {
      const { content, css } = req.body;
      
      // Verificar se já existe um conteúdo
      const existingSettings = await db('settings').first();
      
      if (existingSettings) {
        // Atualizar conteúdo existente
        await db('settings')
          .update({
            homeContent: content,
            homeCss: css,
            updatedAt: new Date()
          });
      } else {
        // Criar novo conteúdo
        await db('settings').insert({
          homeContent: content,
          homeCss: css,
          createdAt: new Date(),
          updatedAt: new Date()
        });
      }
      
      return res.json({ message: 'Conteúdo atualizado com sucesso' });
    } catch (error) {
      console.error('Erro ao atualizar conteúdo:', error);
      return res.status(500).json({ error: 'Erro interno do servidor' });
    }
  }
}

module.exports = { controller: new SettingsController() }; 