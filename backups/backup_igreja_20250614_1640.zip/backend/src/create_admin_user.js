const bcrypt = require('bcrypt');
const { db, initializeDatabase } = require('./database/db');

async function createAdminUser() {
  try {
    await initializeDatabase();
    
    // Verificar se o usuário admin já existe
    const adminUser = await db('users')
      .where('email', 'admin@admin.com')
      .first();

    if (!adminUser) {
      // Criar usuário admin
      const hashedPassword = await bcrypt.hash('admin123', 8);
      await db('users').insert({
        name: 'Admin',
        email: 'admin@admin.com',
        password: hashedPassword,
        is_admin: true
      });
      console.log('Usuário admin criado com sucesso!');
    } else {
      // Atualizar senha do admin
      const hashedPassword = await bcrypt.hash('admin123', 8);
      await db('users')
        .where('email', 'admin@admin.com')
        .update({
          password: hashedPassword,
          is_admin: true
        });
      console.log('Senha do usuário admin atualizada!');
    }

    // Verificar se o usuário foi criado/atualizado
    const user = await db('users')
      .where('email', 'admin@admin.com')
      .first();
    
    console.log('Usuário admin:', user);

    process.exit(0);
  } catch (error) {
    console.error('Erro ao criar usuário admin:', error);
    process.exit(1);
  }
}

createAdminUser(); 