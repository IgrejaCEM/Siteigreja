const fs = require('fs');
const path = require('path');
const db = require('../config/database');

async function migrate() {
  try {
    // Ler e executar arquivos de migração
    const migrationsPath = path.join(__dirname, 'migrations');
    const migrationFiles = fs.readdirSync(migrationsPath)
      .filter(file => file.endsWith('.sql'))
      .sort();

    for (const file of migrationFiles) {
      const sql = fs.readFileSync(path.join(migrationsPath, file), 'utf8');
      console.log(`Executando migração: ${file}`);
      await db.query(sql);
    }

    // Ler e executar arquivos de seed
    const seedsPath = path.join(__dirname, 'seeds');
    const seedFiles = fs.readdirSync(seedsPath)
      .filter(file => file.endsWith('.sql'))
      .sort();

    for (const file of seedFiles) {
      const sql = fs.readFileSync(path.join(seedsPath, file), 'utf8');
      console.log(`Executando seed: ${file}`);
      await db.query(sql);
    }

    console.log('Migrações e seeds executados com sucesso!');
    process.exit(0);
  } catch (error) {
    console.error('Erro ao executar migrações:', error);
    process.exit(1);
  }
}

migrate(); 