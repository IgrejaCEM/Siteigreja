exports.up = async function(db) {
  // Criar tabela de eventos
  if (!(await db.schema.hasTable('events'))) {
    await db.schema.createTable('events', table => {
      table.increments('id').primary();
      table.string('title').notNullable();
      table.text('description');
      table.date('date').notNullable();
      table.string('location');
      table.decimal('price', 10, 2);
      table.string('banner');
      table.string('banner_home');
      table.string('banner_evento');
      table.string('slug').unique();
      table.string('status').defaultTo('active');
      table.timestamps(true, true);
    });
  }

  // Criar tabela de lotes
  if (!(await db.schema.hasTable('lots'))) {
    await db.schema.createTable('lots', table => {
      table.increments('id').primary();
      table.integer('event_id').unsigned().references('id').inTable('events').onDelete('CASCADE');
      table.string('name').notNullable();
      table.decimal('price', 10, 2).notNullable();
      table.integer('quantity').notNullable();
      table.date('start_date');
      table.date('end_date');
      table.timestamps(true, true);
    });
  }

  // Criar tabela de usuários
  if (!(await db.schema.hasTable('users'))) {
    await db.schema.createTable('users', table => {
      table.increments('id').primary();
      table.string('name').notNullable();
      table.string('email').unique().notNullable();
      table.string('password').notNullable();
      table.boolean('is_admin').defaultTo(false);
      table.timestamps(true, true);
    });
  }

  // Criar tabela de inscrições
  if (!(await db.schema.hasTable('registrations'))) {
    await db.schema.createTable('registrations', table => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.integer('event_id').unsigned().references('id').inTable('events').onDelete('CASCADE');
      table.integer('lot_id').unsigned().references('id').inTable('lots').onDelete('SET NULL');
      table.string('status').defaultTo('pending');
      table.string('payment_status').defaultTo('pending');
      table.timestamps(true, true);
    });
  }

  // Criar tabela de pagamentos
  if (!(await db.schema.hasTable('payments'))) {
    await db.schema.createTable('payments', table => {
      table.increments('id').primary();
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.integer('event_id').unsigned().references('id').inTable('events').onDelete('CASCADE');
      table.integer('lot_id').unsigned().references('id').inTable('lots').onDelete('SET NULL');
      table.decimal('amount', 10, 2).notNullable();
      table.string('payment_intent_id');
      table.string('status').defaultTo('pending');
      table.timestamps(true, true);
    });
  }

  // Criar tabela de métodos de pagamento
  if (!(await db.schema.hasTable('payment_methods'))) {
    await db.schema.createTable('payment_methods', table => {
      table.increments('id').primary();
      table.string('name').notNullable();
      table.string('type').notNullable();
      table.string('status').defaultTo('active');
      table.timestamps(true, true);
    });
  }

  // Criar tabela de configurações de pagamento por evento
  if (!(await db.schema.hasTable('event_payment_settings'))) {
    await db.schema.createTable('event_payment_settings', table => {
      table.increments('id').primary();
      table.integer('event_id').unsigned().references('id').inTable('events').onDelete('CASCADE');
      table.json('settings');
      table.timestamps(true, true);
    });
  }
};

exports.down = async function(db) {
  await db.schema.dropTableIfExists('event_payment_settings');
  await db.schema.dropTableIfExists('payment_methods');
  await db.schema.dropTableIfExists('payments');
  await db.schema.dropTableIfExists('registrations');
  await db.schema.dropTableIfExists('users');
  await db.schema.dropTableIfExists('lots');
  await db.schema.dropTableIfExists('events');
}; 