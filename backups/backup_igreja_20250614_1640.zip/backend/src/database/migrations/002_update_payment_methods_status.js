exports.up = async function(db) {
  const exists = await db.schema.hasTable('payment_methods');
  if (exists) {
    // Verificar se a coluna status já existe
    const hasStatusColumn = await db.schema.hasColumn('payment_methods', 'status');
    if (!hasStatusColumn) {
      // Adicionar nova coluna status
      await db.schema.table('payment_methods', table => {
        table.string('status').defaultTo('active');
      });

      // Migrar dados da coluna active para status
      const methods = await db('payment_methods').select('*');
      for (const method of methods) {
        await db('payment_methods')
          .where('id', method.id)
          .update({
            status: method.active ? 'active' : 'inactive'
          });
      }

      // Verificar se a coluna active existe
      const hasActiveColumn = await db.schema.hasColumn('payment_methods', 'active');
      if (hasActiveColumn) {
        // Remover coluna active
        await db.schema.table('payment_methods', table => {
          table.dropColumn('active');
        });
      }
    }
  }
};

exports.down = async function(db) {
  const exists = await db.schema.hasTable('payment_methods');
  if (exists) {
    // Verificar se a coluna active já existe
    const hasActiveColumn = await db.schema.hasColumn('payment_methods', 'active');
    if (!hasActiveColumn) {
      // Adicionar coluna active de volta
      await db.schema.table('payment_methods', table => {
        table.boolean('active').defaultTo(true);
      });

      // Migrar dados da coluna status para active
      const methods = await db('payment_methods').select('*');
      for (const method of methods) {
        await db('payment_methods')
          .where('id', method.id)
          .update({
            active: method.status === 'active'
          });
      }

      // Verificar se a coluna status existe
      const hasStatusColumn = await db.schema.hasColumn('payment_methods', 'status');
      if (hasStatusColumn) {
        // Remover coluna status
        await db.schema.table('payment_methods', table => {
          table.dropColumn('status');
        });
      }
    }
  }
}; 