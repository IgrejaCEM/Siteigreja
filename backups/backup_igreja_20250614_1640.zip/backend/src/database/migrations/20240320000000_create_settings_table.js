exports.up = async function(knex) {
  const exists = await knex.schema.hasTable('settings');
  if (!exists) {
    return knex.schema.createTable('settings', function(table) {
      table.increments('id').primary();
      table.json('homeLayout').nullable();
      table.text('homeContent').nullable();
      table.text('homeCss').nullable();
      table.timestamp('createdAt').defaultTo(knex.fn.now());
      table.timestamp('updatedAt').defaultTo(knex.fn.now());
    });
  } else {
    // Verificar se as colunas existem e adicioná-las se necessário
    const hasHomeLayout = await knex.schema.hasColumn('settings', 'homeLayout');
    const hasHomeContent = await knex.schema.hasColumn('settings', 'homeContent');
    const hasHomeCss = await knex.schema.hasColumn('settings', 'homeCss');

    if (!hasHomeLayout || !hasHomeContent || !hasHomeCss) {
      return knex.schema.table('settings', function(table) {
        if (!hasHomeLayout) table.json('homeLayout').nullable();
        if (!hasHomeContent) table.text('homeContent').nullable();
        if (!hasHomeCss) table.text('homeCss').nullable();
      });
    }
  }
};

exports.down = async function(knex) {
  const exists = await knex.schema.hasTable('settings');
  if (exists) {
    // Verificar se as colunas existem antes de tentar removê-las
    const hasHomeLayout = await knex.schema.hasColumn('settings', 'homeLayout');
    const hasHomeContent = await knex.schema.hasColumn('settings', 'homeContent');
    const hasHomeCss = await knex.schema.hasColumn('settings', 'homeCss');

    if (hasHomeLayout || hasHomeContent || hasHomeCss) {
      return knex.schema.table('settings', function(table) {
        if (hasHomeLayout) table.dropColumn('homeLayout');
        if (hasHomeContent) table.dropColumn('homeContent');
        if (hasHomeCss) table.dropColumn('homeCss');
      });
    }
  }
}; 