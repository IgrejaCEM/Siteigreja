exports.up = async function(knex) {
  const exists = await knex.schema.hasTable('users');
  if (!exists) {
    await knex.schema.createTable('users', table => {
      table.increments('id').primary();
      table.string('name').notNullable();
      table.string('email').notNullable().unique();
      table.string('password').notNullable();
      table.boolean('is_admin').defaultTo(false);
      table.timestamps(true, true);
    });

    // Criar usuário admin padrão
    const bcrypt = require('bcrypt');
    const hash = bcrypt.hashSync('admin123', 8);
    
    await knex('users').insert({
      name: 'Admin',
      email: 'admin@admin.com',
      password: hash,
      is_admin: true
    });
  }
};

exports.down = async function(knex) {
  const exists = await knex.schema.hasTable('users');
  if (exists) {
    return knex.schema.dropTable('users');
  }
}; 