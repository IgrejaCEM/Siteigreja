exports.up = async function(knex) {
  const exists = await knex.schema.hasTable('payments');
  if (!exists) {
    return knex.schema.createTable('payments', table => {
      table.increments('id').primary();
      table.integer('user_id').notNullable().references('id').inTable('users');
      table.integer('event_id').notNullable().references('id').inTable('events');
      table.integer('lote_id').notNullable().references('id').inTable('lots');
      table.decimal('amount', 10, 2).notNullable();
      table.string('payment_intent_id').notNullable();
      table.string('status').notNullable().defaultTo('pending');
      table.json('payment_details').nullable();
      table.string('gateway').notNullable().defaultTo('stripe');
      table.string('currency').notNullable().defaultTo('BRL');
      table.timestamp('created_at').defaultTo(knex.fn.now());
      table.timestamp('updated_at').defaultTo(knex.fn.now());
    });
  }
};

exports.down = async function(knex) {
  const exists = await knex.schema.hasTable('payments');
  if (exists) {
    return knex.schema.dropTable('payments');
  }
}; 