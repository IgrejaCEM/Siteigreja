const knex = require('knex');
const config = require('../../config');

const db = knex(config.database);

async function up() {
  const exists = await db.schema.hasTable('transactions');
  if (!exists) {
    await db.schema.createTable('transactions', table => {
      table.increments('id').primary();
      table.integer('event_id').unsigned().references('id').inTable('events').onDelete('CASCADE');
      table.integer('user_id').unsigned().references('id').inTable('users').onDelete('CASCADE');
      table.decimal('amount', 10, 2).notNullable();
      table.string('payment_method').notNullable();
      table.string('status').notNullable();
      table.json('payment_details');
      table.timestamps(true, true);
    });

    // Criar índices para melhor performance
    await db.schema.raw('CREATE INDEX idx_transactions_event_id ON transactions(event_id)');
    await db.schema.raw('CREATE INDEX idx_transactions_user_id ON transactions(user_id)');
    await db.schema.raw('CREATE INDEX idx_transactions_status ON transactions(status)');
    await db.schema.raw('CREATE INDEX idx_transactions_created_at ON transactions(created_at)');

    console.log('Tabela transactions criada com sucesso!');
  }
}

async function down() {
  const exists = await db.schema.hasTable('transactions');
  if (exists) {
    await db.schema.dropTable('transactions');
    console.log('Tabela transactions removida com sucesso!');
  }
}

module.exports = { up, down }; 