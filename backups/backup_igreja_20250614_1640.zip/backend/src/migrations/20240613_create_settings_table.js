const knex = require('knex');
const config = require('../../config');

const db = knex(config.database);

async function up() {
  const exists = await db.schema.hasTable('settings');
  if (!exists) {
    await db.schema.createTable('settings', table => {
      table.increments('id').primary();
      table.string('key').notNullable().unique();
      table.text('value');
      table.string('type').defaultTo('string');
      table.timestamp('updated_at').defaultTo(db.fn.now());
    });
    console.log('Tabela settings criada com sucesso!');
  }
}

async function down() {
  const exists = await db.schema.hasTable('settings');
  if (exists) {
    await db.schema.dropTable('settings');
    console.log('Tabela settings removida com sucesso!');
  }
}

module.exports = { up, down }; 