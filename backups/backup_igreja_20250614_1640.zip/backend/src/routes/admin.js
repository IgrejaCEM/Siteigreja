const express = require('express');
const router = express.Router();
const { db } = require('../database/db');
const { authenticateToken, requireAdmin } = require('../middleware');

// Página do painel admin
router.get('/', async (req, res) => {
  try {
    // Buscar estatísticas
    const stats = await db('events').count('* as total');
    
    // Buscar configurações
    const settings = await db('settings').first();
    let title = '';
    if (settings && settings.homeLayout) {
      try {
        const layout = JSON.parse(settings.homeLayout);
        title = layout[0]?.content?.title || '';
      } catch (e) {}
    }

    // Se a requisição aceita JSON, retorna as estatísticas
    if (req.accepts('json')) {
      return res.json({ stats });
    }

    // Caso contrário, retorna a página HTML
    res.send(`
      <html>
        <head>
          <title>Painel Admin</title>
          <style>body{font-family:sans-serif;padding:40px;}input{padding:8px;}</style>
        </head>
        <body>
          <h1>Painel Admin</h1>
          <form method="POST" action="/admin">
            <label>Título da Home:</label><br>
            <input name="title" value="${title}" style="width:300px"/><br><br>
            <button type="submit">Salvar</button>
          </form>
          <h2>Preview da Home</h2>
          <iframe src="/" width="100%" height="400" style="border:1px solid #ccc;"></iframe>
        </body>
      </html>
    `);
  } catch (error) {
    console.error('Erro ao carregar painel admin:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Listar eventos
router.get('/events', async (req, res) => {
  try {
    const events = await db('events')
      .select('*')
      .orderBy('created_at', 'desc');
    res.json(events);
  } catch (error) {
    console.error('Erro ao listar eventos:', error);
    res.status(500).json({ error: 'Erro ao listar eventos' });
  }
});

// Criar evento
router.post('/events', async (req, res) => {
  try {
    const [event] = await db('events')
      .insert(req.body)
      .returning('*');
    res.status(201).json(event);
  } catch (error) {
    console.error('Erro ao criar evento:', error);
    res.status(500).json({ error: 'Erro ao criar evento' });
  }
});

// Atualizar evento
router.put('/events/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const [event] = await db('events')
      .where('id', req.params.id)
      .update(req.body)
      .returning('*');
    
    if (!event) {
      return res.status(404).json({ error: 'Evento não encontrado' });
    }
    
    res.json(event);
  } catch (error) {
    console.error('Erro ao atualizar evento:', error);
    res.status(500).json({ error: 'Erro ao atualizar evento' });
  }
});

// Deletar evento
router.delete('/events/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const deleted = await db('events')
      .where('id', req.params.id)
      .del();
    
    if (!deleted) {
      return res.status(404).json({ error: 'Evento não encontrado' });
    }
    
    res.status(204).send();
  } catch (error) {
    console.error('Erro ao deletar evento:', error);
    res.status(500).json({ error: 'Erro ao deletar evento' });
  }
});

// Salvar edição das configurações
router.post('/', authenticateToken, requireAdmin, express.urlencoded({ extended: true }), async (req, res) => {
  try {
    const settings = await db('settings').first();
    let layout = [];
    if (settings && settings.homeLayout) {
      try {
        layout = JSON.parse(settings.homeLayout);
      } catch (e) {}
    }
    // Atualiza o título do primeiro bloco (hero)
    if (layout[0]) {
      layout[0].content = layout[0].content || {};
      layout[0].content.title = req.body.title;
    } else {
      layout = [{ id: Date.now().toString(), type: 'hero', content: { title: req.body.title } }];
    }
    if (settings) {
      await db('settings')
        .update({ 
          homeLayout: JSON.stringify(layout), 
          updatedAt: new Date() 
        });
    } else {
      await db('settings')
        .insert({ 
          homeLayout: JSON.stringify(layout), 
          createdAt: new Date(), 
          updatedAt: new Date() 
        });
    }
    res.redirect('/admin');
  } catch (error) {
    console.error('Erro ao salvar configurações:', error);
    res.status(500).send('Erro interno do servidor');
  }
});

// Buscar evento por ID
router.get('/events/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const event = await db('events')
      .where('id', id)
      .first();

    if (!event) {
      return res.status(404).json({ error: 'Evento não encontrado' });
    }

    // Buscar lotes do evento
    const lots = await db('lots')
      .where('event_id', id)
      .orderBy('price', 'asc');

    res.json({
      ...event,
      banner: event.banner || 'https://via.placeholder.com/1200x400?text=Imagem+do+Evento',
      banner_home: event.banner_home || event.banner || 'https://via.placeholder.com/1200x400?text=Imagem+do+Evento',
      banner_evento: event.banner_evento || event.banner || 'https://via.placeholder.com/1200x400?text=Imagem+do+Evento',
      lots: lots || []
    });
  } catch (error) {
    console.error('Erro ao buscar evento:', error);
    res.status(500).json({ error: 'Erro ao buscar evento' });
  }
});

// Listar todas as inscrições
router.get('/registrations', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const registrations = await db('registrations')
      .select(
        'registrations.*',
        'users.name as user_name',
        'users.email as user_email',
        'events.title as event_title'
      )
      .leftJoin('users', 'registrations.user_id', 'users.id')
      .leftJoin('events', 'registrations.event_id', 'events.id')
      .orderBy('registrations.created_at', 'desc');
    res.json(registrations);
  } catch (error) {
    console.error('Erro ao listar inscrições:', error);
    res.status(500).json({ error: 'Erro ao listar inscrições' });
  }
});

// Listar todos os participantes
router.get('/participants', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const participants = await db('users')
      .select(
        'users.*',
        'registrations.status as registration_status',
        'registrations.created_at as registration_date',
        'events.title as event_title'
      )
      .leftJoin('registrations', 'users.id', 'registrations.user_id')
      .leftJoin('events', 'registrations.event_id', 'events.id')
      .orderBy('users.created_at', 'desc');
    res.json(participants);
  } catch (error) {
    console.error('Erro ao listar participantes:', error);
    res.status(500).json({ error: 'Erro ao listar participantes' });
  }
});

module.exports = router; 