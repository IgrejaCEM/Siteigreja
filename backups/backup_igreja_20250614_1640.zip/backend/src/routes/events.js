const express = require('express');
const router = express.Router();
const { db } = require('../database/db');
const { authenticateToken, requireAdmin } = require('../middleware');

// Listar todos os eventos públicos
router.get('/', async (req, res) => {
  try {
    const events = await db('events')
      .select('*')
      .where('status', 'active')
      .orderBy('date', 'asc');

    res.json(events.map(event => ({
      ...event,
      banner: event.banner || 'https://via.placeholder.com/1200x400?text=Imagem+do+Evento',
      banner_home: event.banner_home || event.banner || 'https://via.placeholder.com/1200x400?text=Imagem+do+Evento',
      banner_evento: event.banner_evento || event.banner || 'https://via.placeholder.com/1200x400?text=Imagem+do+Evento'
    })));
  } catch (error) {
    console.error('Erro ao listar eventos:', error);
    res.status(500).json({ error: 'Erro ao listar eventos' });
  }
});

// Buscar evento por slug
router.get('/:slug', async (req, res) => {
  try {
    const { slug } = req.params;
    const event = await db('events')
      .where('slug', slug)
      .orWhere('id', slug)
      .first();

    if (!event) {
      return res.status(404).json({ error: 'Evento não encontrado' });
    }

    // Buscar lotes do evento
    const lots = await db('lots')
      .where('event_id', event.id)
      .where('status', 'active')
      .orderBy('price', 'asc');

    res.json({
      ...event,
      banner: event.banner || 'https://via.placeholder.com/1200x400?text=Imagem+do+Evento',
      banner_home: event.banner_home || event.banner || 'https://via.placeholder.com/1200x400?text=Imagem+do+Evento',
      banner_evento: event.banner_evento || event.banner || 'https://via.placeholder.com/1200x400?text=Imagem+do+Evento',
      lots: lots || []
    });
  } catch (error) {
    console.error('Erro ao buscar evento:', error);
    res.status(500).json({ error: 'Erro ao buscar evento' });
  }
});

// Criar evento (admin)
router.post('/', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { title, description, date, location, price, banner } = req.body;
    const [id] = await db('events').insert({
      title,
      description,
      date,
      location,
      price,
      banner,
      status: 'active',
      created_at: new Date(),
      updated_at: new Date()
    });
    res.json({ id, ...req.body });
  } catch (error) {
    console.error('Erro ao criar evento:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Atualizar evento (admin)
router.put('/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { title, description, date, location, price, banner, status } = req.body;
    await db('events')
      .where({ id })
      .update({
        title,
        description,
        date,
        location,
        price,
        banner,
        status: status || 'active',
        updated_at: new Date()
      });
    res.json({ id, ...req.body });
  } catch (error) {
    console.error('Erro ao atualizar evento:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

// Excluir evento (admin)
router.delete('/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    await db('events').where({ id }).del();
    res.json({ message: 'Evento excluído com sucesso' });
  } catch (error) {
    console.error('Erro ao excluir evento:', error);
    res.status(500).json({ error: 'Erro interno do servidor' });
  }
});

module.exports = router; 