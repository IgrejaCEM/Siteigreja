const express = require('express');
const router = express.Router();
const adminRoutes = require('./admin');
const eventRoutes = require('./events');
const paymentRoutes = require('./payment');
const settingsRoutes = require('./settings');
const authRoutes = require('./auth');
const financialRoutes = require('./financial.routes');

// Rotas públicas
router.use('/events', eventRoutes);
router.use('/auth', authRoutes);

// Rotas protegidas
router.use('/admin', adminRoutes);
router.use('/financial', financialRoutes);
router.use('/settings', settingsRoutes);
router.use('/payment', paymentRoutes);

module.exports = router; 