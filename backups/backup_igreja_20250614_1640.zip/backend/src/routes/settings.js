const express = require('express');
const router = express.Router();
const { db } = require('../database/db');
const { authenticateToken, requireAdmin } = require('../middleware');

// Get settings
router.get('/', async (req, res) => {
  try {
    const settings = await db('settings').first();
    res.json(settings || {});
  } catch (error) {
    console.error('Error getting settings:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Update settings
router.post('/', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { homeLayout } = req.body;
    // Check if settings exist
    const existingSettings = await db('settings').first();
    if (existingSettings) {
      await db('settings')
        .update({
          homeLayout: JSON.stringify(homeLayout),
          updatedAt: new Date()
        });
    } else {
      await db('settings')
        .insert({
          homeLayout: JSON.stringify(homeLayout),
          createdAt: new Date(),
          updatedAt: new Date()
        });
    }
    res.json({ message: 'Settings updated successfully' });
  } catch (error) {
    console.error('Error updating settings:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Home layout routes
router.get('/home-layout', async (req, res) => {
  try {
    const settings = await db('settings').first();
    const layout = settings?.homeLayout ? JSON.parse(settings.homeLayout) : [];
    res.json({ layout });
  } catch (error) {
    console.error('Error getting home layout:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/home-layout', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { layout } = req.body;
    const settings = await db('settings').first();
    
    if (settings) {
      await db('settings').update({
        homeLayout: JSON.stringify(layout),
        updatedAt: new Date()
      });
    } else {
      await db('settings').insert({
        homeLayout: JSON.stringify(layout),
        createdAt: new Date(),
        updatedAt: new Date()
      });
    }
    
    res.json({ message: 'Home layout updated successfully' });
  } catch (error) {
    console.error('Error updating home layout:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Home content routes
router.get('/home-content', async (req, res) => {
  try {
    const settings = await db('settings').first();
    res.json({
      content: settings?.content || '',
      css: settings?.css || ''
    });
  } catch (error) {
    console.error('Error getting home content:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

router.post('/home-content', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { content, css } = req.body;
    const settings = await db('settings').first();
    
    if (settings) {
      await db('settings').update({
        content,
        css,
        updatedAt: new Date()
      });
    } else {
      await db('settings').insert({
        content,
        css,
        createdAt: new Date(),
        updatedAt: new Date()
      });
    }
    
    res.json({ message: 'Home content updated successfully' });
  } catch (error) {
    console.error('Error updating home content:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

module.exports = router; 