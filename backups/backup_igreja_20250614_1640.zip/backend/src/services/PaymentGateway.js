const axios = require('axios');
const config = require('../config');

class PaymentGateway {
  constructor() {
    this.api = axios.create({
      baseURL: config.payment.baseUrl,
      headers: {
        'Authorization': `Bearer ${config.payment.apiKey}`,
        'Content-Type': 'application/json'
      }
    });
  }

  async createPayment(data) {
    try {
      const response = await this.api.post('/payments', {
        ...data,
        currency: config.payment.defaultCurrency
      });
      return response.data;
    } catch (error) {
      console.error('Error creating payment:', error);
      throw error;
    }
  }

  async getPaymentStatus(paymentId) {
    try {
      const response = await this.api.get(`/payments/${paymentId}`);
      return response.data;
    } catch (error) {
      console.error('Error getting payment status:', error);
      throw error;
    }
  }

  async confirmPayment(paymentId) {
    try {
      const response = await this.api.post(`/payments/${paymentId}/confirm`);
      return response.data;
    } catch (error) {
      console.error('Error confirming payment:', error);
      throw error;
    }
  }

  async refundPayment(paymentId, amount) {
    try {
      // Simulação de reembolso
      return {
        success: true,
        refund: {
          id: `re_${Date.now()}`,
          payment_id: paymentId,
          amount,
          status: 'completed',
          created: Date.now()
        }
      };
    } catch (error) {
      console.error('Erro ao realizar reembolso:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }
}

module.exports = new PaymentGateway(); 