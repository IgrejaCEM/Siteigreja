import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { useAuth } from './contexts/AuthContext';
import ErrorBoundary from './components/ErrorBoundary';

// Pages
import Login from './pages/Login';
import AdminDashboard from './pages/AdminDashboard';
import Eventos from './pages/dashboard/Eventos';
import EditarEvento from './pages/EditarEvento';
import CriarEvento from './pages/CriarEvento';
import Participantes from './pages/dashboard/Participantes';
import Financeiro from './pages/dashboard/Financeiro';
import FinanceiroWrapper from './pages/dashboard/FinanceiroWrapper';
import EditorHome from './pages/dashboard/EditorHome';
import Editor from './pages/dashboard/Editor';
import Home from './pages/Home';
import Evento from './pages/Evento';
import { AdminLayout } from './components/Sidebar';

// Styles
import './App.css';

const theme = createTheme({
  palette: {
    primary: {
      main: '#1976d2',
    },
    secondary: {
      main: '#dc004e',
    },
  },
  typography: {
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    h4: {
      fontWeight: 600,
    },
  },
});

export default function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider theme={theme}>
        <Router>
          <Routes>
            {/* Rotas Públicas */}
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/evento/:slug" element={<Evento />} />
            
            {/* Rotas Admin */}
            <Route path="/admin/*" element={
              <AdminLayout>
                <Routes>
                  <Route path="/" element={<AdminDashboard />} />
                  <Route path="eventos" element={<Eventos />} />
                  <Route path="participantes" element={<Participantes />} />
                  <Route path="financeiro" element={<Financeiro />} />
                  <Route path="editor-home" element={<EditorHome />} />
                  <Route path="editor" element={<Editor />} />
                  <Route path="criar-evento" element={<CriarEvento />} />
                  <Route path="editar-evento/:id" element={<EditarEvento />} />
                  <Route path="financeiro-evento/:id" element={<FinanceiroWrapper />} />
                </Routes>
              </AdminLayout>
            } />
          </Routes>
        </Router>
      </ThemeProvider>
    </ErrorBoundary>
  );
}
