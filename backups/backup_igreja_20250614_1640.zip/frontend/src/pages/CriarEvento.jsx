import React, { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import {
  Box,
  Typography,
  TextField,
  Button,
  Grid,
  Card,
  CardContent,
  IconButton,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Alert,
  Divider,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
} from '@mui/material';
import {
  Add as AddIcon,
  Delete as DeleteIcon,
  Save as SaveIcon,
  Image as ImageIcon,
  Edit as EditIcon,
  Preview as PreviewIcon
} from '@mui/icons-material';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import dayjs from 'dayjs';
import api from '../services/api';
import { styled } from '@mui/material/styles';
import FormFieldsManager from '../components/FormFieldsManager';
import EventoPreview from '../components/EventoPreview';

const VisuallyHiddenInput = styled('input')`
  clip: rect(0 0 0 0);
  clip-path: inset(50%);
  height: 1px;
  overflow: hidden;
  position: absolute;
  bottom: 0;
  left: 0;
  white-space: nowrap;
  width: 1px;
`;

const CriarEvento = () => {
  const navigate = useNavigate();
  const { id } = useParams(); // Para edição de evento
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  // Estado principal do evento
  const [eventData, setEventData] = useState({
    title: '',
    description: '',
    date: null,
    location: '',
    banner: null,
    banner_home: null,
    banner_evento: null,
    registration_form: [],
    has_payment: false,
    payment_gateway: 'stripe',
    currency: 'BRL',
  });

  // Estado para lotes
  const [lots, setLots] = useState([{
    name: '',
    price: '',
    quantity: '',
    start_date: null,
    end_date: null
  }]);

  // Estado para campos do formulário
  const [requiredFields, setRequiredFields] = useState({
    cpf: false,
    age: false,
    gender: false,
    address: false,
    imageAuth: false
  });

  const [customFields, setCustomFields] = useState([]);

  // Estado para configurações de pagamento
  const [paymentSettings, setPaymentSettings] = useState({
    stripe_key: '',
    mercadopago_key: '',
    pagseguro_key: '',
    payment_methods: ['credit_card', 'pix', 'boleto']
  });

  const [previewMode, setPreviewMode] = useState(false);

  // Carregar dados do evento para edição
  useEffect(() => {
    const loadEventData = async () => {
      if (id) {
        try {
          setLoading(true);
          const response = await api.get(`/admin/events/${id}`);
          const event = response.data;

          setEventData({
            title: event.title,
            description: event.description,
            date: dayjs(event.date),
            location: event.location,
            banner: event.banner,
            banner_home: event.banner_home,
            banner_evento: event.banner_evento,
            has_payment: event.has_payment,
            payment_gateway: event.payment_gateway || 'stripe',
            currency: event.currency || 'BRL',
          });

          setLots(event.lots || [{
            name: '',
            price: '',
            quantity: '',
            start_date: null,
            end_date: null
          }]);

          setRequiredFields(event.required_fields || {
            cpf: false,
            age: false,
            gender: false,
            address: false,
            imageAuth: false
          });

          setCustomFields(event.custom_fields || []);

          setPaymentSettings(event.payment_settings || {
            stripe_key: '',
            mercadopago_key: '',
            pagseguro_key: '',
            payment_methods: ['credit_card', 'pix', 'boleto']
          });
        } catch (error) {
          setError('Erro ao carregar dados do evento. Tente novamente.');
        } finally {
          setLoading(false);
        }
      }
    };

    loadEventData();
  }, [id]);

  // Handler para validar URLs de imagem
  const validateImageUrl = (url) => {
    return url.match(/\.(jpeg|jpg|gif|png|webp)$/i) != null;
  };

  // Handler para lotes
  const handleAddLot = () => {
    setLots([...lots, {
      name: '',
      price: '',
      quantity: '',
      start_date: null,
      end_date: null
    }]);
  };

  const handleRemoveLot = (index) => {
    setLots(lots.filter((_, i) => i !== index));
  };

  const handleLotChange = (index, field, value) => {
    const newLots = [...lots];
    newLots[index] = {
      ...newLots[index],
      [field]: value
    };
    setLots(newLots);
  };

  // Handler para salvar evento
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const eventPayload = {
        ...eventData,
        date: eventData.date ? eventData.date.toISOString() : null,
        lots: lots.map(lot => ({
          ...lot,
          start_date: lot.start_date ? lot.start_date.toISOString() : null,
          end_date: lot.end_date ? lot.end_date.toISOString() : null
        })),
        required_fields: requiredFields,
        custom_fields: customFields,
        payment_settings: paymentSettings
      };

      let response;
      if (id) {
        response = await api.put(`/admin/events/${id}`, eventPayload);
      } else {
        response = await api.post('/admin/events', eventPayload);
      }

      setSuccess(true);
      navigate('/admin/eventos');
    } catch (err) {
      console.error('Erro ao salvar evento:', err);
      setError(err.response?.data?.message || 'Erro ao salvar evento. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  const handlePreviewUpdate = (updatedEventData) => {
    setEventData(prev => ({
      ...prev,
      ...updatedEventData
    }));
  };

  return (
    <Box sx={{ p: 3, maxWidth: 1200, mx: 'auto' }}>
      <Typography variant="h4" gutterBottom>
        {id ? 'Editar Evento' : 'Criar Novo Evento'}
      </Typography>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      {success && (
        <Alert severity="success" sx={{ mb: 2 }}>
          Evento criado com sucesso! Redirecionando...
        </Alert>
      )}

      <Box sx={{ mb: 4 }}>
        <Button
          variant="outlined"
          onClick={() => setPreviewMode(!previewMode)}
          startIcon={previewMode ? <EditIcon /> : <PreviewIcon />}
          sx={{ mb: 2 }}
        >
          {previewMode ? 'Voltar para Edição' : 'Modo Preview'}
        </Button>

        {previewMode ? (
          <EventoPreview
            eventData={eventData}
            onUpdate={handlePreviewUpdate}
          />
        ) : (
          <form onSubmit={handleSubmit}>
            <Grid container spacing={3}>
              {/* Informações Básicas */}
              <Grid xs={12}>
                <Card>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Informações Básicas
                    </Typography>
                    <Grid container spacing={2}>
                      <Grid xs={12}>
                        <TextField
                          fullWidth
                          label="Título do Evento"
                          value={eventData.title}
                          onChange={(e) => setEventData({...eventData, title: e.target.value})}
                          required
                        />
                      </Grid>
                      <Grid xs={12}>
                        <TextField
                          fullWidth
                          multiline
                          rows={4}
                          label="Descrição"
                          value={eventData.description}
                          onChange={(e) => setEventData({...eventData, description: e.target.value})}
                          required
                        />
                      </Grid>
                      <Grid xs={12} sm={6}>
                        <LocalizationProvider dateAdapter={AdapterDayjs}>
                          <DatePicker
                            label="Data do Evento"
                            value={eventData.date}
                            onChange={(newValue) => setEventData({...eventData, date: newValue})}
                            slotProps={{
                              textField: {
                                fullWidth: true,
                                required: true
                              }
                            }}
                          />
                        </LocalizationProvider>
                      </Grid>
                      <Grid xs={12} sm={6}>
                        <TextField
                          fullWidth
                          label="Local"
                          value={eventData.location}
                          onChange={(e) => setEventData({...eventData, location: e.target.value})}
                          required
                        />
                      </Grid>
                    </Grid>
                  </CardContent>
                </Card>
              </Grid>

              {/* Banners */}
              <Grid xs={12}>
                <Card>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Banners e Imagens
                    </Typography>
                    <Grid container spacing={2}>
                      <Grid xs={12} sm={4}>
                        <TextField
                          fullWidth
                          label="URL do Banner Principal"
                          value={eventData.banner || ''}
                          onChange={(e) => setEventData({...eventData, banner: e.target.value})}
                          placeholder="https://exemplo.com/imagem.jpg"
                          helperText="Cole a URL da imagem"
                        />
                        <Typography variant="caption" color="textSecondary" sx={{ display: 'block', mt: 1, mb: 2 }}>
                          Tamanho recomendado: 1920x1080 pixels
                        </Typography>
                        {eventData.banner && (
                          <Box sx={{ mt: 2, position: 'relative' }}>
                            <img 
                              src={eventData.banner} 
                              alt="Preview" 
                              style={{ width: '100%', height: '100px', objectFit: 'cover', borderRadius: '4px' }}
                              onError={(e) => {
                                e.target.onerror = null;
                                e.target.src = 'https://via.placeholder.com/400x200?text=Imagem+Inválida';
                              }}
                            />
                          </Box>
                        )}
                      </Grid>
                      <Grid xs={12} sm={4}>
                        <TextField
                          fullWidth
                          label="URL do Banner Home"
                          value={eventData.banner_home || ''}
                          onChange={(e) => setEventData({...eventData, banner_home: e.target.value})}
                          placeholder="https://exemplo.com/imagem.jpg"
                          helperText="Cole a URL da imagem"
                        />
                        <Typography variant="caption" color="textSecondary" sx={{ display: 'block', mt: 1, mb: 2 }}>
                          Tamanho recomendado: 800x600 pixels
                        </Typography>
                        {eventData.banner_home && (
                          <Box sx={{ mt: 2, position: 'relative' }}>
                            <img 
                              src={eventData.banner_home} 
                              alt="Preview" 
                              style={{ width: '100%', height: '100px', objectFit: 'cover', borderRadius: '4px' }}
                              onError={(e) => {
                                e.target.onerror = null;
                                e.target.src = 'https://via.placeholder.com/400x200?text=Imagem+Inválida';
                              }}
                            />
                          </Box>
                        )}
                      </Grid>
                      <Grid xs={12} sm={4}>
                        <TextField
                          fullWidth
                          label="URL do Banner Evento"
                          value={eventData.banner_evento || ''}
                          onChange={(e) => setEventData({...eventData, banner_evento: e.target.value})}
                          placeholder="https://exemplo.com/imagem.jpg"
                          helperText="Cole a URL da imagem"
                        />
                        <Typography variant="caption" color="textSecondary" sx={{ display: 'block', mt: 1, mb: 2 }}>
                          Tamanho recomendado: 1200x400 pixels
                        </Typography>
                        {eventData.banner_evento && (
                          <Box sx={{ mt: 2, position: 'relative' }}>
                            <img 
                              src={eventData.banner_evento} 
                              alt="Preview" 
                              style={{ width: '100%', height: '100px', objectFit: 'cover', borderRadius: '4px' }}
                              onError={(e) => {
                                e.target.onerror = null;
                                e.target.src = 'https://via.placeholder.com/400x200?text=Imagem+Inválida';
                              }}
                            />
                          </Box>
                        )}
                      </Grid>
                    </Grid>
                  </CardContent>
                </Card>
              </Grid>

              {/* Lotes */}
              <Grid xs={12}>
                <Card>
                  <CardContent>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                      <Typography variant="h6">
                        Lotes
                      </Typography>
                      <Button
                        startIcon={<AddIcon />}
                        onClick={handleAddLot}
                        variant="contained"
                        size="small"
                      >
                        Adicionar Lote
                      </Button>
                    </Box>
                    
                    <TableContainer component={Paper}>
                      <Table>
                        <TableHead>
                          <TableRow>
                            <TableCell>Nome</TableCell>
                            <TableCell>Preço</TableCell>
                            <TableCell>Quantidade</TableCell>
                            <TableCell>Data Início</TableCell>
                            <TableCell>Data Fim</TableCell>
                            <TableCell>Ações</TableCell>
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {lots.map((lot, index) => (
                            <TableRow key={index}>
                              <TableCell>
                                <TextField
                                  fullWidth
                                  size="small"
                                  value={lot.name}
                                  onChange={(e) => handleLotChange(index, 'name', e.target.value)}
                                />
                              </TableCell>
                              <TableCell>
                                <TextField
                                  fullWidth
                                  size="small"
                                  type="number"
                                  value={lot.price}
                                  onChange={(e) => handleLotChange(index, 'price', e.target.value)}
                                />
                              </TableCell>
                              <TableCell>
                                <TextField
                                  fullWidth
                                  size="small"
                                  type="number"
                                  value={lot.quantity}
                                  onChange={(e) => handleLotChange(index, 'quantity', e.target.value)}
                                />
                              </TableCell>
                              <TableCell>
                                <LocalizationProvider dateAdapter={AdapterDayjs}>
                                  <DatePicker
                                    value={lot.start_date}
                                    onChange={(newValue) => handleLotChange(index, 'start_date', newValue)}
                                    slotProps={{
                                      textField: {
                                        size: "small"
                                      }
                                    }}
                                  />
                                </LocalizationProvider>
                              </TableCell>
                              <TableCell>
                                <LocalizationProvider dateAdapter={AdapterDayjs}>
                                  <DatePicker
                                    value={lot.end_date}
                                    onChange={(newValue) => handleLotChange(index, 'end_date', newValue)}
                                    slotProps={{
                                      textField: {
                                        size: "small"
                                      }
                                    }}
                                  />
                                </LocalizationProvider>
                              </TableCell>
                              <TableCell>
                                <IconButton
                                  onClick={() => handleRemoveLot(index)}
                                  color="error"
                                  size="small"
                                >
                                  <DeleteIcon />
                                </IconButton>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  </CardContent>
                </Card>
              </Grid>

              {/* Formulário de Inscrição */}
              <Grid item xs={12}>
                <Card>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Formulário de Inscrição
                    </Typography>
                    <FormFieldsManager
                      requiredFields={requiredFields}
                      onRequiredFieldsChange={setRequiredFields}
                      customFields={customFields}
                      onCustomFieldsChange={setCustomFields}
                    />
                  </CardContent>
                </Card>
              </Grid>

              {/* Configurações de Pagamento */}
              <Grid item xs={12}>
                <Card>
                  <CardContent>
                    <Typography variant="h6" gutterBottom>
                      Configurações de Pagamento
                    </Typography>
                    
                    <Grid container spacing={2}>
                      <Grid xs={12}>
                        <FormControl fullWidth>
                          <InputLabel>Habilitar Pagamento</InputLabel>
                          <Select
                            value={eventData.has_payment}
                            onChange={(e) => setEventData({...eventData, has_payment: e.target.value})}
                            label="Habilitar Pagamento"
                          >
                            <MenuItem value={true}>Sim</MenuItem>
                            <MenuItem value={false}>Não</MenuItem>
                          </Select>
                        </FormControl>
                      </Grid>

                      {eventData.has_payment && (
                        <>
                          <Grid xs={12} sm={6}>
                            <FormControl fullWidth>
                              <InputLabel>Gateway de Pagamento</InputLabel>
                              <Select
                                value={eventData.payment_gateway}
                                onChange={(e) => setEventData({...eventData, payment_gateway: e.target.value})}
                                label="Gateway de Pagamento"
                              >
                                <MenuItem value="stripe">Stripe</MenuItem>
                                <MenuItem value="mercadopago">Mercado Pago</MenuItem>
                                <MenuItem value="pagseguro">PagSeguro</MenuItem>
                              </Select>
                            </FormControl>
                          </Grid>

                          <Grid xs={12} sm={6}>
                            <FormControl fullWidth>
                              <InputLabel>Moeda</InputLabel>
                              <Select
                                value={eventData.currency}
                                onChange={(e) => setEventData({...eventData, currency: e.target.value})}
                                label="Moeda"
                              >
                                <MenuItem value="BRL">Real (BRL)</MenuItem>
                                <MenuItem value="USD">Dólar (USD)</MenuItem>
                              </Select>
                            </FormControl>
                          </Grid>

                          <Grid xs={12}>
                            <TextField
                              fullWidth
                              label="Chave da API (Gateway)"
                              value={paymentSettings[`${eventData.payment_gateway}_key`]}
                              onChange={(e) => setPaymentSettings({
                                ...paymentSettings,
                                [`${eventData.payment_gateway}_key`]: e.target.value
                              })}
                            />
                          </Grid>
                        </>
                      )}
                    </Grid>
                  </CardContent>
                </Card>
              </Grid>

              {/* Botões de Ação */}
              <Grid item xs={12}>
                <Box sx={{ display: 'flex', justifyContent: 'flex-end', gap: 2 }}>
                  <Button
                    variant="outlined"
                    onClick={() => navigate('/admin/events')}
                  >
                    Cancelar
                  </Button>
                  <Button
                    type="submit"
                    variant="contained"
                    startIcon={<SaveIcon />}
                    disabled={loading}
                  >
                    {loading ? 'Salvando...' : 'Salvar Evento'}
                  </Button>
                </Box>
              </Grid>
            </Grid>
          </form>
        )}
      </Box>
    </Box>
  );
};

export default CriarEvento; 