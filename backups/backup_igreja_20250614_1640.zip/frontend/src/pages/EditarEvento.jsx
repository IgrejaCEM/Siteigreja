import { useEffect, useState } from 'react';
import { Box, Button, Typography, TextField, Paper, Grid, InputAdornment } from '@mui/material';
import { useNavigate, useParams } from 'react-router-dom';
import api from '../services/api';

export default function EditarEvento() {
  const { id } = useParams();
  const [form, setForm] = useState({
    title: '',
    date: '',
    location: '',
    description: '',
    banner: '',
    banner_home: '',
    banner_evento: '',
    price: '',
  });
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchEvento = async () => {
      try {
        const res = await api.get(`/admin/events/${id}`);
        setForm({
          title: res.data.title || '',
          date: res.data.date || '',
          location: res.data.location || '',
          description: res.data.description || '',
          banner: res.data.banner || '',
          banner_home: res.data.banner_home || '',
          banner_evento: res.data.banner_evento || '',
          price: res.data.price || '',
        });
        setLoading(false);
      } catch (error) {
        console.error('Erro ao carregar evento:', error);
        navigate('/admin/eventos');
      }
    };
    fetchEvento();
  }, [id, navigate]);

  const handleChange = e => {
    const { name, value } = e.target;
    setForm(f => ({ ...f, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await api.put(`/admin/events/${id}`, form);
      navigate('/admin/eventos');
    } catch (error) {
      console.error('Erro ao atualizar evento:', error);
    }
  };

  if (loading) {
    return <Typography>Carregando...</Typography>;
  }

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h4" sx={{ mb: 4 }}>Editar Evento</Typography>
      <Paper sx={{ p: 3 }}>
        <form onSubmit={handleSubmit}>
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Título"
                name="title"
                value={form.title}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Data"
                type="datetime-local"
                name="date"
                value={form.date}
                onChange={handleChange}
                InputLabelProps={{ shrink: true }}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Local"
                name="location"
                value={form.location}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                multiline
                rows={4}
                label="Descrição"
                name="description"
                value={form.description}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Banner"
                name="banner"
                value={form.banner}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Banner Home"
                name="banner_home"
                value={form.banner_home}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Banner Evento"
                name="banner_evento"
                value={form.banner_evento}
                onChange={handleChange}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Preço"
                name="price"
                type="number"
                value={form.price}
                onChange={handleChange}
                InputProps={{
                  startAdornment: <InputAdornment position="start">R$</InputAdornment>,
                }}
              />
            </Grid>
            <Grid item xs={12}>
              <Box sx={{ display: 'flex', gap: 2, justifyContent: 'flex-end' }}>
                <Button onClick={() => navigate('/admin/eventos')}>
                  Cancelar
                </Button>
                <Button type="submit" variant="contained" color="primary">
                  Salvar
                </Button>
              </Box>
            </Grid>
          </Grid>
        </form>
      </Paper>
    </Box>
  );
} 