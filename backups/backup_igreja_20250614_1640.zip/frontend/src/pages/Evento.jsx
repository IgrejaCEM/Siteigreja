import React, { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Box, Container, Typography, Grid, Paper, Button, Divider, Chip, Alert, CircularProgress } from '@mui/material';
import {
  Event as EventIcon,
  LocationOn as LocationIcon,
  AccessTime as TimeIcon,
  AttachMoney as MoneyIcon
} from '@mui/icons-material';
import dayjs from 'dayjs';
import 'dayjs/locale/pt-br';
import api from '../services/api';
import ModernHeader from '../components/ModernHeader';
import Footer from '../components/Footer';
import WhatsAppButton from '../components/WhatsAppButton';

dayjs.locale('pt-br');

const Evento = () => {
  const { slug } = useParams();
  const [event, setEvent] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const loadEvent = async () => {
      try {
        const response = await api.get(`/events/${slug}`);
        setEvent(response.data);
      } catch (error) {
        console.error('Erro ao carregar evento:', error);
        setError('Erro ao carregar o evento. Tente novamente mais tarde.');
      } finally {
        setLoading(false);
      }
    };

    loadEvent();
  }, [slug]);

  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh">
        <CircularProgress />
      </Box>
    );
  }

  if (error) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh">
        <Alert severity="error">{error}</Alert>
      </Box>
    );
  }

  if (!event) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="100vh">
        <Typography>Evento não encontrado</Typography>
      </Box>
    );
  }

  const nextLot = event.lots?.find(lot => 
    dayjs(lot.end_date).isAfter(dayjs()) && lot.quantity > 0
  );

  return (
    <Box>
      <ModernHeader />
      
      <Box
        component="img"
        src={event.banner_evento || event.banner || '/placeholder-event.jpg'}
        alt={event.title}
        sx={{
          width: '100%',
          height: '400px',
          objectFit: 'cover',
          mb: 4
        }}
      />

      <Container maxWidth="lg" sx={{ mb: 8 }}>
        <Grid container spacing={4}>
          <Grid item xs={12} md={8}>
            <Typography variant="h3" component="h1" gutterBottom>
              {event.title}
            </Typography>

            <Box sx={{ display: 'flex', gap: 2, mb: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <TimeIcon sx={{ mr: 1, color: 'text.secondary' }} />
                <Typography variant="body1" color="text.secondary">
                  {dayjs(event.date).format('DD [de] MMMM [de] YYYY [às] HH:mm')}
                </Typography>
              </Box>

              <Box sx={{ display: 'flex', alignItems: 'center' }}>
                <LocationIcon sx={{ mr: 1, color: 'text.secondary' }} />
                <Typography variant="body1" color="text.secondary">
                  {event.location}
                </Typography>
              </Box>
            </Box>

            <Typography variant="body1" paragraph>
              {event.description}
            </Typography>

            {event.additional_info && (
              <>
                <Typography variant="h5" gutterBottom sx={{ mt: 4 }}>
                  Informações Adicionais
                </Typography>
                <Typography variant="body1" paragraph>
                  {event.additional_info}
                </Typography>
              </>
            )}
          </Grid>

          <Grid item xs={12} md={4}>
            <Paper elevation={3} sx={{ p: 3 }}>
              <Typography variant="h5" gutterBottom>
                Ingressos
              </Typography>

              {nextLot ? (
                <>
                  <Box sx={{ mb: 3 }}>
                    <Typography variant="subtitle1" color="primary" gutterBottom>
                      {nextLot.name}
                    </Typography>
                    <Typography variant="h4" color="primary" gutterBottom>
                      {nextLot.price > 0 ? `R$ ${nextLot.price.toFixed(2)}` : 'Gratuito'}
                    </Typography>
                    <Chip
                      label={`${nextLot.quantity} vagas disponíveis`}
                      color="primary"
                      variant="outlined"
                      sx={{ mt: 1 }}
                    />
                  </Box>

                  <Button
                    variant="contained"
                    size="large"
                    fullWidth
                    startIcon={<MoneyIcon />}
                    onClick={() => window.location.href = `/inscricao/${event.slug}`}
                  >
                    Inscrever-se
                  </Button>
                </>
              ) : (
                <Alert severity="warning">
                  Ingressos esgotados ou fora do período de vendas
                </Alert>
              )}
            </Paper>
          </Grid>
        </Grid>
      </Container>

      <Footer />
      <WhatsAppButton />
    </Box>
  );
};

export default Evento; 