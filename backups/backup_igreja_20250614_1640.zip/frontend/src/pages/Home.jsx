import React, { useEffect, useState } from 'react';
import { Box, Typography, Button, Grid, Container, Card, CardContent, CardMedia, CardActions, Skeleton, Alert, Chip, Divider } from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { API_BASE_URL } from '../config';
import ModernHeader from '../components/ModernHeader';
import HeroSection from '../components/HeroSection';
import Footer from '../components/Footer';
import WhatsAppButton from '../components/WhatsAppButton';
import {
  Event as EventIcon,
  LocationOn as LocationIcon,
  AccessTime as TimeIcon
} from '@mui/icons-material';
import dayjs from 'dayjs';
import 'dayjs/locale/pt-br';
import api from '../services/api';

dayjs.locale('pt-br');

const Home = () => {
  const [content, setContent] = useState('');
  const [css, setCss] = useState('');
  const [loading, setLoading] = useState(true);
  const [events, setEvents] = useState([]);
  const [layout, setLayout] = useState([]);
  const navigate = useNavigate();
  const [error, setError] = useState('');

  useEffect(() => {
    const loadContent = async () => {
      try {
        setLoading(true);
        // Carregar o conteúdo personalizado
        const contentResponse = await api.get('/settings/home-content');
        setContent(contentResponse.data.content || '');
        setCss(contentResponse.data.css || '');

        // Carregar o layout personalizado
        const layoutResponse = await api.get('/settings/home-layout');
        setLayout(layoutResponse.data?.layout || []);

        // Carregar eventos
        const eventsResponse = await api.get('/events');
        setEvents(eventsResponse.data);
      } catch (error) {
        console.error('Erro ao carregar conteúdo:', error);
        setError('Erro ao carregar eventos. Tente novamente mais tarde.');
      } finally {
        setLoading(false);
      }
    };

    loadContent();
  }, []);

  const handleEventClick = (event) => {
    navigate(`/evento/${event.slug}`);
  };

  const getNextAvailableLot = (lots) => {
    if (!lots || lots.length === 0) return null;
    
    const now = dayjs();
    return lots
      .filter(lot => dayjs(lot.end_date).isAfter(now) && lot.quantity > 0)
      .sort((a, b) => dayjs(a.start_date).diff(dayjs(b.start_date)))[0];
  };

  if (loading) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '100vh' }}>
        <Typography>Carregando...</Typography>
      </Box>
    );
  }

  // Se houver layout personalizado, usar ele
  if (layout.length > 0) {
    return (
      <Box>
        <ModernHeader />
        {layout.map((component) => {
          switch (component.type) {
            case 'hero':
              return <HeroSection key={component.id} content={component.content} />;

            case 'events':
              return (
                <Box key={component.id} sx={{ py: 4, bgcolor: '#f5f5f5' }}>
                  <Container>
                    <Typography variant="h3" sx={{ mb: 4, textAlign: 'center', fontWeight: 'bold', color: '#1976d2' }}>
                      {component.content.title || 'Próximos Eventos'}
                    </Typography>
                    <Grid container spacing={3}>
                      {error && (
                        <Grid item xs={12}>
                          <Alert severity="error" sx={{ mb: 4 }}>
                            {error}
                          </Alert>
                        </Grid>
                      )}
                      {events.length > 0 ? (
                        events.map((event) => {
                          const nextLot = getNextAvailableLot(event.lots);
                          
                          return (
                            <Grid item xs={12} sm={6} md={4} key={event.id}>
                              <Card
                                sx={{
                                  height: '100%',
                                  display: 'flex',
                                  flexDirection: 'column',
                                  transition: 'transform 0.2s',
                                  '&:hover': {
                                    transform: 'translateY(-4px)',
                                    boxShadow: 6
                                  }
                                }}
                              >
                                <CardMedia
                                  component="img"
                                  height="200"
                                  image={event.banner_home || event.banner || '/placeholder-event.jpg'}
                                  alt={event.title}
                                  sx={{ objectFit: 'cover' }}
                                />
                                <CardContent sx={{ flexGrow: 1 }}>
                                  <Typography variant="h5" gutterBottom>
                                    {event.title}
                                  </Typography>
                                  
                                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                                    <TimeIcon sx={{ mr: 1, color: 'text.secondary' }} />
                                    <Typography variant="body2" color="text.secondary">
                                      {dayjs(event.date).format('DD [de] MMMM [de] YYYY [às] HH:mm')}
                                    </Typography>
                                  </Box>
                                  
                                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                                    <LocationIcon sx={{ mr: 1, color: 'text.secondary' }} />
                                    <Typography variant="body2" color="text.secondary">
                                      {event.location}
                                    </Typography>
                                  </Box>

                                  <Typography
                                    variant="body2"
                                    color="text.secondary"
                                    sx={{
                                      mb: 2,
                                      display: '-webkit-box',
                                      WebkitLineClamp: 3,
                                      WebkitBoxOrient: 'vertical',
                                      overflow: 'hidden'
                                    }}
                                  >
                                    {event.description}
                                  </Typography>

                                  {nextLot && (
                                    <Box sx={{ mb: 2 }}>
                                      <Divider sx={{ my: 1 }} />
                                      <Typography variant="subtitle2" color="primary" gutterBottom>
                                        {nextLot.name}
                                      </Typography>
                                      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                                        <Typography variant="h6" color="primary">
                                          {nextLot.price > 0
                                            ? `R$ ${nextLot.price.toFixed(2)}`
                                            : 'Gratuito'}
                                        </Typography>
                                        <Chip
                                          label={`${nextLot.quantity} vagas`}
                                          color="primary"
                                          size="small"
                                          variant="outlined"
                                        />
                                      </Box>
                                    </Box>
                                  )}
                                </CardContent>
                                <CardActions>
                                  <Button
                                    variant="contained"
                                    fullWidth
                                    onClick={() => handleEventClick(event)}
                                    startIcon={<EventIcon />}
                                  >
                                    Ver Detalhes
                                  </Button>
                                </CardActions>
                              </Card>
                            </Grid>
                          );
                        })
                      ) : (
                        <Grid item xs={12}>
                          <Typography variant="h6" textAlign="center" color="text.secondary">
                            Nenhum evento disponível no momento.
                          </Typography>
                        </Grid>
                      )}
                    </Grid>
                  </Container>
                </Box>
              );

            default:
              return null;
          }
        })}
        <Footer />
        <WhatsAppButton />
      </Box>
    );
  }

  // Layout padrão se não houver personalização
  return (
    <Box>
      <ModernHeader />
      <Box sx={{ py: 4, bgcolor: '#f5f5f5' }}>
        <Container>
          <Typography variant="h3" sx={{ mb: 4, textAlign: 'center', fontWeight: 'bold', color: '#1976d2' }}>
            Próximos Eventos
          </Typography>
          <Grid container spacing={3}>
            {error && (
              <Grid item xs={12}>
                <Alert severity="error" sx={{ mb: 4 }}>
                  {error}
                </Alert>
              </Grid>
            )}
            {events.length > 0 ? (
              events.map((event) => {
                const nextLot = getNextAvailableLot(event.lots);
                
                return (
                  <Grid item xs={12} sm={6} md={4} key={event.id}>
                    <Card
                      sx={{
                        height: '100%',
                        display: 'flex',
                        flexDirection: 'column',
                        transition: 'transform 0.2s',
                        '&:hover': {
                          transform: 'translateY(-4px)',
                          boxShadow: 6
                        }
                      }}
                    >
                      <CardMedia
                        component="img"
                        height="200"
                        image={event.banner_home || event.banner || '/placeholder-event.jpg'}
                        alt={event.title}
                        sx={{ objectFit: 'cover' }}
                      />
                      <CardContent sx={{ flexGrow: 1 }}>
                        <Typography variant="h5" gutterBottom>
                          {event.title}
                        </Typography>
                        
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                          <TimeIcon sx={{ mr: 1, color: 'text.secondary' }} />
                          <Typography variant="body2" color="text.secondary">
                            {dayjs(event.date).format('DD [de] MMMM [de] YYYY [às] HH:mm')}
                          </Typography>
                        </Box>
                        
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                          <LocationIcon sx={{ mr: 1, color: 'text.secondary' }} />
                          <Typography variant="body2" color="text.secondary">
                            {event.location}
                          </Typography>
                        </Box>

                        <Typography
                          variant="body2"
                          color="text.secondary"
                          sx={{
                            mb: 2,
                            display: '-webkit-box',
                            WebkitLineClamp: 3,
                            WebkitBoxOrient: 'vertical',
                            overflow: 'hidden'
                          }}
                        >
                          {event.description}
                        </Typography>

                        {nextLot && (
                          <Box sx={{ mb: 2 }}>
                            <Divider sx={{ my: 1 }} />
                            <Typography variant="subtitle2" color="primary" gutterBottom>
                              {nextLot.name}
                            </Typography>
                            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                              <Typography variant="h6" color="primary">
                                {nextLot.price > 0
                                  ? `R$ ${nextLot.price.toFixed(2)}`
                                  : 'Gratuito'}
                              </Typography>
                              <Chip
                                label={`${nextLot.quantity} vagas`}
                                color="primary"
                                size="small"
                                variant="outlined"
                              />
                            </Box>
                          </Box>
                        )}
                      </CardContent>
                      <CardActions>
                        <Button
                          variant="contained"
                          fullWidth
                          onClick={() => handleEventClick(event)}
                          startIcon={<EventIcon />}
                        >
                          Ver Detalhes
                        </Button>
                      </CardActions>
                    </Card>
                  </Grid>
                );
              })
            ) : (
              <Grid item xs={12}>
                <Typography variant="h6" textAlign="center" color="text.secondary">
                  Nenhum evento disponível no momento.
                </Typography>
              </Grid>
            )}
          </Grid>
        </Container>
      </Box>
      <Footer />
      <WhatsAppButton />
    </Box>
  );
};

export default Home;
