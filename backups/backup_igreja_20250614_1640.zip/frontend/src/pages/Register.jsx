import { useState, useEffect } from "react";
import axios from "axios";
import { TextField, Button, Typography, Box, Alert } from "@mui/material";
import { useNavigate } from "react-router-dom";
import { API_BASE_URL } from "../config";

export default function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleRegister = async (e) => {
    e.preventDefault();
    setError("");
    try {
      const res = await axios.post(`${API_BASE_URL}/register`, {
        name,
        email,
        password,
        is_admin: false // Sempre participante
      });
      // Login automático após cadastro
      const loginRes = await axios.post(`${API_BASE_URL}/login`, {
        email,
        password
      });
      localStorage.setItem("token", loginRes.data.token);
      setName(""); setEmail(""); setPassword("");
      navigate("/home"); // Redireciona para a página Home
    } catch (err) {
      setError("Erro ao criar conta. Tente outro e-mail.");
    }
  };

  useEffect(() => {
    document.body.style.background = "#fff";
    document.body.style.color = "#222";
    return () => {
      document.body.style.background = "";
      document.body.style.color = "";
    };
  }, []);

  return (
    <Box className="container mt-5" maxWidth={400} mx="auto">
      <Typography variant="h5" gutterBottom>Criar Conta</Typography>
      <form onSubmit={handleRegister}>
        <TextField label="Nome" fullWidth margin="normal" value={name} onChange={e => setName(e.target.value)} required />
        <TextField label="E-mail" type="email" fullWidth margin="normal" value={email} onChange={e => setEmail(e.target.value)} required />
        <TextField label="Senha" type="password" fullWidth margin="normal" value={password} onChange={e => setPassword(e.target.value)} required />
        <Button type="submit" variant="contained" color="primary" fullWidth>Criar Conta</Button>
        {error && <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>}
      </form>
    </Box>
  );
} 