import HomeLayoutEditor from './HomeLayoutEditor';

export default function SiteEditor() {
  return <HomeLayoutEditor />;
} 