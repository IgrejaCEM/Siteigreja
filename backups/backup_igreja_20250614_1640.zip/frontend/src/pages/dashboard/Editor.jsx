import { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  Grid,
  Card,
  CardContent,
  CardActions,
  Button,
  CircularProgress,
  Alert
} from '@mui/material';
import { useNavigate } from 'react-router-dom';
import EditIcon from '@mui/icons-material/Edit';
import HomeIcon from '@mui/icons-material/Home';
import SettingsIcon from '@mui/icons-material/Settings';
import api from '../../services/api';

export default function Editor() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const editorOptions = [
    {
      title: 'Editor da Página Inicial',
      description: 'Edite o conteúdo da página inicial do site, incluindo banners, textos e seções.',
      icon: <HomeIcon sx={{ fontSize: 40, color: '#1976d2' }} />,
      path: '/admin/editor-home'
    },
    {
      title: 'Configurações Gerais',
      description: 'Configure as opções gerais do site, como informações de contato e redes sociais.',
      icon: <SettingsIcon sx={{ fontSize: 40, color: '#4CAF50' }} />,
      path: '/admin/editor-settings'
    }
  ];

  return (
    <Paper sx={{ p: 3, backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
      <Box sx={{ 
        backgroundColor: 'white',
        p: 2,
        borderRadius: 1,
        boxShadow: 1,
        mb: 4
      }}>
        <Typography variant="h4" sx={{ color: '#1976d2', fontWeight: 'bold' }}>
          Editor do Site
        </Typography>
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>
      )}

      <Grid container spacing={3}>
        {editorOptions.map((option, index) => (
          <Grid item xs={12} md={6} key={index}>
            <Card sx={{ 
              height: '100%',
              display: 'flex',
              flexDirection: 'column',
              transition: 'transform 0.2s, box-shadow 0.2s',
              '&:hover': {
                transform: 'translateY(-4px)',
                boxShadow: 4
              }
            }}>
              <CardContent sx={{ flexGrow: 1 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                  {option.icon}
                  <Typography variant="h5" sx={{ ml: 2, color: '#1976d2', fontWeight: 'bold' }}>
                    {option.title}
                  </Typography>
                </Box>
                <Typography variant="body1" color="text.secondary">
                  {option.description}
                </Typography>
              </CardContent>
              <CardActions sx={{ p: 2, borderTop: '1px solid #eee' }}>
                <Button
                  startIcon={<EditIcon />}
                  variant="contained"
                  onClick={() => navigate(option.path)}
                  sx={{
                    fontWeight: 'bold',
                    '&:hover': {
                      backgroundColor: '#1565c0'
                    }
                  }}
                >
                  Editar
                </Button>
              </CardActions>
            </Card>
          </Grid>
        ))}
      </Grid>
    </Paper>
  );
} 