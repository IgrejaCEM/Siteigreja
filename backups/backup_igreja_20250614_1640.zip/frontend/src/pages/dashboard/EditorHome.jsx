import { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  TextField,
  Button,
  Grid,
  CircularProgress,
  Alert
} from '@mui/material';
import api from '../../services/api';

export default function EditorHome() {
  const [content, setContent] = useState({
    title: '',
    subtitle: '',
    banner: '',
    about: '',
    mission: '',
    vision: ''
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    const fetchContent = async () => {
      try {
        const response = await api.get('/admin/home-content');
        setContent(response.data);
        setLoading(false);
      } catch (err) {
        console.error('Erro ao carregar conteúdo:', err);
        setError('Erro ao carregar conteúdo');
        setLoading(false);
      }
    };

    fetchContent();
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setContent(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setError('');
    setSuccess('');

    try {
      await api.put('/admin/home-content', content);
      setSuccess('Conteúdo atualizado com sucesso!');
    } catch (err) {
      console.error('Erro ao salvar conteúdo:', err);
      setError('Erro ao salvar conteúdo');
    } finally {
      setSaving(false);
    }
  };

  return (
    <Paper sx={{ p: 3, backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
      <Box sx={{ 
        backgroundColor: 'white',
        p: 2,
        borderRadius: 1,
        boxShadow: 1,
        mb: 4
      }}>
        <Typography variant="h4" sx={{ color: '#1976d2', fontWeight: 'bold' }}>
          Editor da Página Inicial
        </Typography>
      </Box>

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <form onSubmit={handleSubmit}>
          <Grid container spacing={3}>
            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Título Principal"
                name="title"
                value={content.title}
                onChange={handleChange}
                sx={{ bgcolor: 'white' }}
              />
            </Grid>

            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Subtítulo"
                name="subtitle"
                value={content.subtitle}
                onChange={handleChange}
                sx={{ bgcolor: 'white' }}
              />
            </Grid>

            <Grid item xs={12}>
              <TextField
                fullWidth
                label="URL do Banner"
                name="banner"
                value={content.banner}
                onChange={handleChange}
                placeholder="https://..."
                sx={{ bgcolor: 'white' }}
              />
            </Grid>

            <Grid item xs={12}>
              <TextField
                fullWidth
                label="Sobre Nós"
                name="about"
                value={content.about}
                onChange={handleChange}
                multiline
                rows={4}
                sx={{ bgcolor: 'white' }}
              />
            </Grid>

            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Missão"
                name="mission"
                value={content.mission}
                onChange={handleChange}
                multiline
                rows={4}
                sx={{ bgcolor: 'white' }}
              />
            </Grid>

            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Visão"
                name="vision"
                value={content.vision}
                onChange={handleChange}
                multiline
                rows={4}
                sx={{ bgcolor: 'white' }}
              />
            </Grid>

            {error && (
              <Grid item xs={12}>
                <Alert severity="error">{error}</Alert>
              </Grid>
            )}

            {success && (
              <Grid item xs={12}>
                <Alert severity="success">{success}</Alert>
              </Grid>
            )}

            <Grid item xs={12}>
              <Box sx={{ display: 'flex', justifyContent: 'flex-end' }}>
                <Button
                  type="submit"
                  variant="contained"
                  disabled={saving}
                  sx={{
                    fontWeight: 'bold',
                    '&:hover': {
                      backgroundColor: '#1565c0'
                    }
                  }}
                >
                  {saving ? <CircularProgress size={24} /> : 'Salvar Alterações'}
                </Button>
              </Box>
            </Grid>
          </Grid>
        </form>
      )}
    </Paper>
  );
} 