import { useState, useEffect } from 'react';
import {
  Box,
  Paper,
  Typography,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  CircularProgress,
  Alert
} from '@mui/material';
import api from '../../services/api';

export default function Participantes() {
  const [participantes, setParticipantes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchParticipantes = async () => {
      try {
        const response = await api.get('/admin/participants');
        setParticipantes(response.data);
        setLoading(false);
      } catch (err) {
        console.error('Erro ao carregar participantes:', err);
        setError('Erro ao carregar participantes');
        setLoading(false);
      }
    };

    fetchParticipantes();
  }, []);

  return (
    <Paper sx={{ p: 3, backgroundColor: '#f5f5f5', minHeight: '100vh' }}>
      <Box sx={{ 
        backgroundColor: 'white',
        p: 2,
        borderRadius: 1,
        boxShadow: 1,
        mb: 4
      }}>
        <Typography variant="h4" sx={{ color: '#1976d2', fontWeight: 'bold' }}>
          Participantes
        </Typography>
      </Box>

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', mt: 4 }}>
          <CircularProgress />
        </Box>
      ) : error ? (
        <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>
      ) : (
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Nome</TableCell>
                <TableCell>Email</TableCell>
                <TableCell>Telefone</TableCell>
                <TableCell>Eventos Inscritos</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {participantes.map((participante) => (
                <TableRow key={participante.id}>
                  <TableCell>{participante.name}</TableCell>
                  <TableCell>{participante.email}</TableCell>
                  <TableCell>{participante.phone}</TableCell>
                  <TableCell>{participante.events?.length || 0}</TableCell>
                </TableRow>
              ))}
              {participantes.length === 0 && (
                <TableRow>
                  <TableCell colSpan={4} align="center">
                    Nenhum participante encontrado
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
      )}
    </Paper>
  );
} 